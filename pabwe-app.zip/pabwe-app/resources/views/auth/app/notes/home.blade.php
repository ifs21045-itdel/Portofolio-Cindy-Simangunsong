@extends("layouts.app")

@section("content")
<div>
    <a href="{{route("note.add")}}" class="btn btn-primary">Edit Sertifikat</a>
@endsection
