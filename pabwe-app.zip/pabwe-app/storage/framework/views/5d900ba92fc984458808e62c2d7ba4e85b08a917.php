<?php $__env->startSection("content"); ?>
<div class="card-body">
    <h1>Ubah Catatan</h1>
    <hr/>

    <form action="<?php echo e(route("post.login")); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="inputEmail" class="form-label">Email</label>
            <input type="email" name="email" id="inputEmail" class="form-control">
            <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="inputPassword" class="form-label">Password</label>
            <input type="password" name="password" id="inputPassword" class="form-control">
            <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 text-end">
            <button class="btn btn-primary" type="submit">Masuk</button>
        </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cindy\OneDrive\Gambar\Dokumen\SEMESTTER 5\tantangan-praktikum\port-laravel\pabwe-app\resources\views/auth/passwords/notes/add.blade.php ENDPATH**/ ?>