<?php $__env->startSection("content"); ?>
<div>
    <a href="<?php echo e(route("note.add")); ?>" class="btn btn-primary">Tambah Data</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cindy\OneDrive\Gambar\Dokumen\SEMESTTER 5\tantangan-praktikum\port-laravel\pabwe-app\resources\views/app/home.blade.php ENDPATH**/ ?>